# Bot-Gasmon

🔻🔻CZYTAJ OPIS🔻🔻

Macie tutaj mojego bocika essa (wrzucam go bo sajmonik mnie wkur***) 

🔸TUTAJ MACIE WSZYSTKIE OPISANE RZECZY Z PLIKU "botconfig.json": https://pastebin.com/rC9fXDNN 🔸

🛑🛑JEŻELI KTOŚ MA BŁĄD Z INSTALACJĄ MODUŁU quick.db ODSYŁAM DO TEGO --> https://github.com/TrueXPixels/quick.db/issues/125 🛑🛑

🔸Nie pomagam z instalacją więc nie wypisujcie do mnie bo coś nie działa etc.🔸

🛑🛑Jeżeli coś chcecie co on ma na tym "Project Developers coś tam" piszcie do mnie na pw to wam dam kod :))) 🛑🛑

Twórcy bota:
Has52/Gasper
I tam trochę sajmonik coś zrobił (a nie czekaj kurwa zajebał kod z neta i sprzedawał xDDDDD)

Jeżeli chcecie abym coś dodał do tego bota waszego możecie wysłać na pw :)) 

Pozdro 600


A PS JEŻELI KTOŚ KUPIŁ OD NIEGO BOTA W PRZECIĄGU OSTATNICH 2 TYGODNI MOŻECIE ZROBIĆ REFUNDA :)) (ZWRÓT PIENIĘDZY) JEŻELI PŁACILIŚCIE PAYPALEM :)))))




OGÓLNIE TEŻ ZAPRASZAM NA DISCORD'A MOJEGO SERWERKA ALLENVIS.EU

Strona: http://allenvis.eu/

I TEŻ OGÓLNIE W CHUJ BARDZO ZAPRASZAM NA DISCORDA LILABYTE O NAZWIE BYTE-NETWORK W CHUJ ZAJEBISTY SERWER MOZECIE TAM KUPIC SKRYPTY ESSA I POZDRO

Link do dc: https://discord.gg/nZKNfSt
